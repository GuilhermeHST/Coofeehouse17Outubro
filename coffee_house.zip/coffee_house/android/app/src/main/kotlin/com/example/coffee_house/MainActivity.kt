package com.example.coffee_house

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
