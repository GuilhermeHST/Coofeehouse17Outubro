class SessaoCafe {
  final String imagem;
  final String titulo;

  SessaoCafe({
    required this.imagem,
    required this.titulo,
  });
}